# C17 Studio
A dark PWA podcast mixer prototype with Web Audio, recording, 3 channels, master controls, FX/presets and TikTok OAuth server integration.

## Run locally
1. Copy `.env.example` to `.env` and fill values.
2. `npm install`
3. `npm start`

## TikTok
TikTok Web Login Kit requires a registered HTTPS static redirect URI. Set `TIKTOK_REDIRECT_URI` to the exact URI registered in TikTok Developer Portal. The client secret stays server-side. This project uses TikTok's current v2 authorization URL and token endpoint.

Important: the `GO LIVE` button is a studio-state control, not a claim that TikTok Live streaming has been activated. Actual TikTok LIVE/streaming access depends on TikTok's approved products/APIs and account eligibility.
