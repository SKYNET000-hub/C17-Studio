import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import crypto from 'crypto';

const app=express();
const PORT=process.env.PORT||3000;
app.use(express.json({limit:'2mb'}));
app.use(session({secret:process.env.SESSION_SECRET||'dev-only-change-me',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:86400000}}));
app.use(express.static('public'));
const cfg=()=>({key:process.env.TIKTOK_CLIENT_KEY,secret:process.env.TIKTOK_CLIENT_SECRET,redirect:process.env.TIKTOK_REDIRECT_URI});
app.get('/auth/tiktok',(req,res)=>{const c=cfg(); if(!c.key||!c.secret||!c.redirect)return res.status(503).send('TikTok is not configured yet.'); const state=crypto.randomBytes(24).toString('hex'); req.session.tiktokState=state; const u=new URL('https://www.tiktok.com/v2/auth/authorize/'); u.searchParams.set('client_key',c.key);u.searchParams.set('response_type','code');u.searchParams.set('scope','user.info.basic');u.searchParams.set('redirect_uri',c.redirect);u.searchParams.set('state',state);res.redirect(u.toString());});
app.get('/auth/tiktok/callback',async(req,res)=>{try{const c=cfg(); if(!req.query.code||req.query.state!==req.session.tiktokState)return res.status(400).send('TikTok authorization could not be verified.'); delete req.session.tiktokState; const body=new URLSearchParams({client_key:c.key,client_secret:c.secret,code:req.query.code,grant_type:'authorization_code',redirect_uri:c.redirect}); const r=await fetch('https://open.tiktokapis.com/v2/oauth/token/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body}); const data=await r.json(); if(!r.ok)return res.status(400).json(data); req.session.tiktok={access_token:data.access_token,refresh_token:data.refresh_token,expires_at:Date.now()+((data.expires_in||86400)*1000)};res.redirect('/?tiktok=connected');}catch(e){res.status(500).send('TikTok connection failed.');}});
app.get('/api/tiktok/status',(req,res)=>res.json({connected:!!req.session.tiktok}));
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.listen(PORT,()=>console.log(`C17 Studio running on ${PORT}`));
